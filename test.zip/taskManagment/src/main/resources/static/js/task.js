
    var TaskPageScript = function () {
        var variable = {
    		url_get_all_task_items: contextPath + "/task/all",
    		url_create_task:contextPath + "/task/create",
    		url_delete_task: contextPath + "/task/delete",
    		pageContentData: null
    		
        };
        var selector = {
           grid: "#grid",
           btnAddItem: "#add-item-btn",
           ddl_action_status : "#ddl-action-status",
           refresh_grid_filter : "#reset-filter-grid",
           add_task_popup : "#AddTaskModal",
           template_add_task_popup: "#tmplAddTaskModal",      
           form_add_item: "#frmAddItem",         
           btnAddTask:"#add-task-btn",
           formAddTask:"#frmAddTask",
           frmChangeStatus:"#frmChangeStatus",
           
           all_users : []
        };

        var fn = {
            init: function () {
            	fn.pageInit();
            },
            loader : function (target) {
                var element = $(target);
                kendo.ui.progress(element, true);    
            },
            pageInit: function () {
            	fn.loader(document.body);
            	ods.remoting.executeGet(variable.url_get_all_task_items ,"JSON", function(response) {
            		selector.all_users = response.responseData;
            		fn.bindGrid(response.responseData);
            	}, function (jqXHR, status, err) {
                	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                		fn.mboxError(jqXHR.responseJSON.message, "Error");
                		kendo.ui.progress($(document.body), false);
                		return false;
                	}
                	fn.mboxError("failure", "Error");
                });
        
            	$(selector.btnAddTask).click(function(){
                     var template = $.templates(selector.template_add_task_popup);
	                 var templateOutput = $(template.render());
	                 templateOutput.find(".datepicker").datepicker({
	                      dateFormat: 'dd-MM-yy'
	                 });
		            $(selector.add_task_popup).empty().append(templateOutput);
		            $(selector.add_task_popup).modal({show: true , backdrop : 'static'});
		            		 
           		 	 fn.initButtonClicks();
		          
            	});	
            },
            
            
            bindGrid: function (result) {
            	
            	variable.actionGrid = $(selector.grid).kendoGrid({
								            	    dataSource : {
									data : result,
									pageSize : 20,
								            	    },
            	    filterable: true,
            	    groupable: false,
                    sortable: true,
                    scrollable: true,
            	      serverPaging: false,
            	      serverSorting: false,
            	      serverFiltering: false,
            	    pageable: {
            	        refresh: false,
            	        pageSizes: true,
            	        buttonCount: 5
            	    },
                    dataBound: function() {
                        this.expandRow(this.tbody.find("tr.k-master-row").first());
                    },
            	    columns: [

            	        {
            	            field: "taskName",
            	            title: "Task Name",
            	            filterable: {
            	                multi: true,
            	                search: true
            	            },
            	            attributes: {
                             	"class": "table-cell"
                            },
            	            width:110
            	        },
            	        {
            	            field: "taskDesc",
            	            title: "Description",
            	            filterable: {
            	                multi: true,
            	                search: true
            	            },
            	            attributes: {
                             	"class": "table-cell"
                            },
            	            width:80
            	        },

            	        {
            	        	field: "taskStartDateStr",
            	            title: "Start Date",
            	            filterable: {
            	                multi: true,
            	                search: true
            	            },
            	            width:120,
            	            attributes: {
                             	"class": "table-cell"
                             },
            	        },
            	        {
            	            field: "taskEndDateStr",
            	            title: "End Date",
            	            filterable: {
            	                multi: true,
            	                search: true
            	            },
            	            width:120,
            	            attributes: {
                             	"class": "table-cell"
                             },
            	        },
            	        {
            	            field: "taskStatus",
            	            title: "Status",
            	            filterable: {
            	                multi: true,
            	                search: true
            	            },
            	            title: "Status",
            	            width:80,
            	            attributes: {
                             	"class": "table-cell"
                             }
            	        },
            	       
            	       
            	        
            	        { command: { text: "Change Status", click: changeStatus }, title: "Action ", width: "120px"  },
            	        { 
            	          command: { text: "delete", click: deleteRow }, title: "Action ", width: "70px" }
            	        
            	        ],
               	     dataBound: function(e) {
               	    	 
               	    	var len=$("#grid").data("kendoGrid").dataSource.total();
          	    	   $("#length").text(len);
               		
            	    }
            	    
                   
            	}).data("kendoGrid"); 
            	
            	function changeStatus(e) {
             		
             		var gridData = $(selector.grid).data("kendoGrid");
            		var rowData = gridData.dataItem($(e.currentTarget).closest("tr"));
                	var template = $.templates(selector.template_add_task_popup);
                	
                	var templateOutput = $(template.render());
                	templateOutput.find(".datepicker").datepicker({
                        dateFormat: 'dd-MM-yy'
                    });
            		 $(selector.add_task_popup).empty().append(templateOutput);
            		 
            		 var formCurrent = $(selector.formAddTask);
           			formCurrent.find("#taskName").val(rowData.taskName);
           			formCurrent.find("#taskDesc").val(rowData.taskDesc);	              		
           			formCurrent.find("#taskStartDate").val(rowData.taskStartDateStr);
           			formCurrent.find("#taskId").val(rowData.id);
           			formCurrent.find("#taskEndDate").val(rowData.taskEndDateStr);	              			
           			formCurrent.find("#taskStatus").val(rowData.taskStatus);
           			document.getElementById("taskName").disabled = true;
           			document.getElementById("taskDesc").disabled = true;
           			document.getElementById("taskStartDate").disabled = true;
           			
            		 $(selector.add_task_popup).modal({show: true , backdrop : 'static'});
             	
            		 fn.initButtonClicks();
             	}
            	
            	
       	function deleteRow(e) {
       		var gridData = $(selector.grid).data("kendoGrid");
    		var dataItem = gridData.dataItem($(e.currentTarget).closest("tr")); 
            		console.log(dataItem.id);
            		var message = "Do you want to Delete this record ?";
                	var title = "Confirmation";
                	
                    var okOpt = function(){
                    	
                 
                   
                	var deleteTaskUrl = variable.url_delete_task
					+"/"+ encodeURIComponent(dataItem.id);
                	ods.remoting.executeGet(deleteTaskUrl, "JSON", function(response) {
                		if(response.status == "SUCCESS") {
                			fn.mbox(response.message,"Message");
            				return false;
            			}
                	})
                	, function (jqXHR, status, err) {
                    	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    		fn.mboxError(jqXHR.responseJSON.message, "Error");
                    		kendo.ui.progress($(document.body), false);
                    		return false;
                    	}
                    	fn.mboxError("failure", "Error");
                    }
       				}
       				var cancleOpt = function(){  
       				  
       					$(selector.grid).data('kendoGrid').dataSource.read();        				  
            		}
            		
            		customDialog(message, title,okOpt,cancleOpt); 
            		e.stopPropagation()();
                }   	

     	
            	var dataSourcePage = $(selector.grid).data("kendoGrid").dataSource,
                total = dataSourcePage.total();
             
            	dataSourcePage.pageSize(total);
            	dataSourcePage.bind("dataBound", function () {
            		//$("#grid").find(".k-pager-wrap").hide();
                    this.pager.element.hide();
            });
            	 $(selector.refresh_grid_filter).click(function() {
               	    // Clear the grid filters
               	    var gridDataSource = $(selector.grid).data("kendoGrid").dataSource;
               	    for (var i = 0; i < gridDataSource.options.fields.length - 1; i++) {
               	        gridDataSource.filter({ field: gridDataSource.options.fields[i].field, value: "" });
               	    }
               	    gridDataSource.filter([]);
               	});
            	 
            	 
            	 kendo.ui.progress($(document.body), false);
            	 
            },
            initButtonClicks: function(){
            	$(selector.formAddTask).submit(function(e){
            		
            		var frm = $(this);
            		 var validatorFormAdd = $("#frmAddTask").kendoValidator().data("kendoValidator");
            		 validatorFormAdd.validate()
            		
            		 
            		 $(selector.add_task_popup).modal('hide');
            		
            		 var taskId = frm.find("#taskId").val();
            		var taskName = frm.find("#taskName").val();
            		var taskDesc = frm.find("#taskDesc").val();
            		var taskStartDateStr = frm.find("#taskStartDate").val();
            		var taskEndDateStr = frm.find("#taskEndDate").val();
            		var taskStatus = frm.find("#taskStatus").val();
            		    
            		
            			var data = {
            					id:taskId,
            					taskName : taskName,
            					taskDesc : taskDesc,
            					taskStartDateStr : taskStartDateStr,
            					taskEndDateStr : taskEndDateStr,
                				status : status,
                				taskStatus : taskStatus
                    	};
            			
            			var message=[];
            			
            			if(taskId=="")
            				message="Task Created Successfully.";
            			else
            				message="Task Updated Successfully.";
            			
            		
            	
            		var addURL = variable.url_create_task;
            		ods.remoting.executePost(addURL, "JSON", JSON.stringify(data), "application/json; charset=utf-8", false, false, function (response) {
            			if(response.status != "SUCCESS") {
            				fn.mboxError(response.message,"Error");
            				return false;
            			}
            			fn.mbox(message,"Message");
            			
                    }, function (jqXHR, status, err) {
                    	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    		fn.mboxError(jqXHR.responseJSON.message, "Error");
                    		return false;
                    	}
                    	fn.mboxError("failure", "Error");
                    });
            		return false;
            	});
            	
            },
               mbox: function (message, title) {
                BootstrapDialog.show({
                    title: title || 'Message',
                    closable: false,
                    message: message,
                    buttons: [{
                        label: 'Ok',
                        action: function(dialog) {
                        	
                			ods.remoting.executeGet(variable.url_get_all_task_items , "JSON", function(response) {
                          		selector.all_users = response.responseData;
                          		fn.bindGrid(response.responseData);
                          		 $(selector.add_task_popup).modal('hide');
                          		dialog.close();
                          	}, function (jqXHR, status, err) {
                              	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                              		fn.mboxError(jqXHR.responseJSON.message, "Error");
                              		return false;
                              	}
                              	fn.mboxError("failure", "Error");
                            });	
                        
                        }
                    }]
                });
            },
            mboxError: function (message,title) {
                BootstrapDialog.show({
                    title:  title || 'Error',
                    closable: false,
                    message: message,
                    buttons: [{
                        label: 'Ok',
                        action: function(dialog) {               		
                          		dialog.close();
                            }
                    }]
                });
            
        },
        }
        return {
            init: function () {
                fn.init();
            }
        };

    }();

    jQuery(document).ready(function ($) {
        $(function () {
        	TaskPageScript.init();
           
        });
    });