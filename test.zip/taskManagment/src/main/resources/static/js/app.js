

$(document).ready(function(){
	$("#tbl-projects").DataTable();

	$( ".date-picker" ).datepicker({
	    changeMonth: true,
	    numberOfMonths: 1,
	    dateFormat: "yy-mm-dd",
	    onClose: function( selectedDate ) {
	    }
	  });
	
	$("#projectNav").addClass("active");

});

//$( "#frm-new-project" ).submit(function( event ) {
//		var action = $("#frm-new-project").attr('action');
//		var newAction = action + "?role=" + role;
//		$(this).attr('action',newAction);
//});
	
function deleteRowAccomplishments(obj) {
	$(obj).closest('tr').remove();
};

function deleteRowRisk(obj) {
	$(obj).closest('tr').remove();
};

function closeRowRisk(obj) {
	$(obj).closest('td').find(':first-child').attr('value',"Closed");
	obj.closest('tr').bgColor= "#d9f3df";
	var closedTr = $(obj).closest('tr')[0];
	console.log($(obj).closest('tr')[0]);
	//$("#tbl-closed-risks tbody").append(closedTr);
	
		
	var recordId = $(obj).closest('tr').find('.id').val();	
	
	$.ajax({
		type : 'GET',
		url : contextPath +'/project/risk/status/'+recordId+'/Closed',
		success : function(data) {
			console.log(data);
			if (data.status == "SUCCESS") {
				
				$(obj).closest('tr').remove();
				
				
				$('#tbl-closed-risks tbody').append('<tr><td><input disabled="disabled"  class="form-control date-picker txtRaisedDate" required="required" type="text"  value="'+moment(new Date(data.responseData.raisedDate)).format("DD-MMM-YYYY")+'"  /></td>'+
						'<td><textarea rows="10" cols="50" disabled="disabled" class="form-control txtName" type="text">'+data.responseData.name+'</textarea></td>'+
						'<td><input disabled="disabled" class="form-control txtOwner" type="text"  value="'+data.responseData.owner+'" /></td>'+
						'<td><input disabled="disabled" class="form-control date-picker txtTargetDate" required="required" type="text"  value="'+ moment(new Date(data.responseData.targetDate)).format("DD-MMM-YYYY")+'" /></td>'+
						'<td><textarea rows="10" cols="50" disabled="disabled" class="form-control txtRickImpact" type="text">'+data.responseData.impact+'</textarea></td>'+
						'<td><textarea rows="10" cols="50" disabled="disabled" class="form-control txtRiskMitigationStrategy" type="text">'+data.responseData.mitigationStrategy+'</textarea></td>'+
						'<td><input disabled="disabled" class="form-control status" type="hidden" value="'+data.responseData.status+'"/></td></tr>');
				

				
				 BootstrapDialog.show({
             title: data.status || 'Message',
             message: data.message,
             buttons: [{
                 label: 'Ok',
                 action: function(dialog) {
                 	//window.location.reload(true);
                	 dialog.close();
                 }
             }]
         });
				
				
			}
		},
		error : function(jqXHR, textStatus, errorThrown) {
			// console.log(textStatus);
			//window.location.href = 'errorpage';
		},
	});
	
};

function deleteRowOdsProject(obj) {
	$(obj).closest('tr').remove();
};

function addMoreAccomplishments() {
		var allTrs = $("#tbl-accomplishments").find('tr');
		
		if(allTrs.length == 1){
		      $('#tbl-accomplishments tbody').append('<tr><td><textarea class="form-control" id="accomplishments[0].accopName" name="accomplishments[0].accopName"></textarea></td>'+
		    		  '<td><textarea class="form-control" id="accomplishments[0].plannedActivity" name="accomplishments[0].plannedActivity"></textarea></td>'+
		    		  '<td><textarea class="form-control" id="accomplishments[0].milestone" name="accomplishments[0].milestone"></textarea></td>'+
		    		  '<td><input class="form-control date-picker" required="required" type="text" id="accomplishments[0].dueDate" name="accomplishments[0].dueDate"/></td>'+
		    		  '<td><input class="form-control" type="text" id="accomplishments[0].owner" name="accomplishments[0].owner" /></td>'+
		    		  '<td><input class="form-control" type="text" id="accomplishments[0].status" name="accomplishments[0].status" /></td>'+
		    		  '<td><button type="button" value="Delete" id="accomplishments[0]-delete" class="btn btn-danger width100 pull-right acc-delete-row" onclick="deleteRowAccomplishments(this)" ><i class="fa fa-trash" aria-hidden="true"></i> Delete</button></td></tr>');
		      $("#accomplishments[0]-delete").click(deleteRowAccomplishments);
		}else{		
		var lastTr = allTrs[allTrs.length-1];
		var $clone = $(lastTr).clone();
        $clone.find('td').each(function(){
            var el = $(this).find(':first-child');
            var id = el.attr('id') || null;
            if(id) {
            	var idParts = id.split('.');
            	var idx = parseInt(idParts[0].substring(idParts[0].indexOf('[')+1,idParts[0].indexOf(']')));
            	idx += 1;
            	
            	var finalName ='accomplishments[' + idx + '].' + idParts[1];
            	el.attr('id', finalName);
               
                /*delete button */
                var clazz = el.attr('class');
                if(clazz.indexOf('date-picker') > 0){
                	
                	
                	/*var clsName = 'date'+idx;
                	el.addClass(clsName);*/
                	/*$(el).datepicker({
                		 changeMonth: true,
                		    numberOfMonths: 1,
                		    maxDate : "0",
                		    onClose: function( selectedDate ) {
                		    }
                    });*/
                }
                
                if(clazz && clazz.indexOf('acc-delete-row') > 0){
                	el.on("click",deleteRowAccomplishments);
                }else{
                	 el.attr('name', finalName);
                     el.attr('value','');
                }
            }
           
        });
        $clone.find('input:text').val('');
        $clone.find('textarea').val('');
 
       
        $(lastTr).closest('table').append($clone);
        
 

	}
				
		$("#tbl-accomplishments").find(".date-picker").removeClass('hasDatepicker').datepicker({
    		 changeMonth: true,
	  		    numberOfMonths: 1,
	  		    maxDate : "0",
	  		    onClose: function( selectedDate ) {
	  		    }
	   });
}


function addMoreOdsProjects() {
	var allTrs = $("#tbl-ods-projects").find('tr');
	
	if(allTrs.length == 1){
	      $('#tbl-ods-projects tbody').append('<tr><td><textarea class="form-control" id="odsprojects[0].projectName" name="odsprojects[0].projectName"></textarea></td>'+
	    		  '<td><textarea class="form-control" id="odsprojects[0].summary" name="odsprojects[0].summary"></textarea></td>'+
	    		  '<td><textarea class="form-control" id="odsprojects[0].phase" name="odsprojects[0].phase"></textarea></td>'+
	    		  '<td><input class="form-control" type="text" id="odsprojects[0].completeDate" name="odsprojects[0].completeDate"/></td>'+
	    		  '<td><button type="button" value="Delete" id="odsprojects[0]-delete" class="btn btn-danger width100 pull-right acc-delete-row" onclick="deleteRowOdsProject(this)" ><i class="fa fa-trash" aria-hidden="true"></i> Delete</button></td></tr>');
	      $("#odsprojects[0]-delete").click(deleteRowOdsProject);
	}else{		
	var lastTr = allTrs[allTrs.length-1];
	var $clone = $(lastTr).clone();
    $clone.find('td').each(function(){
        var el = $(this).find(':first-child');
        var id = el.attr('id') || null;
        if(id) {
        	var idParts = id.split('.');
        	var idx = parseInt(idParts[0].substring(idParts[0].indexOf('[')+1,idParts[0].indexOf(']')));
        	idx += 1;
        	
        	var finalName ='odsprojects[' + idx + '].' + idParts[1];
        	el.attr('id', finalName);
           
            /*delete button */
            var clazz = el.attr('class');
            if(clazz.indexOf('date-picker') > 0){
            	
            	
            	/*var clsName = 'date'+idx;
            	el.addClass(clsName);*/
            	/*$(el).datepicker({
            		 changeMonth: true,
            		    numberOfMonths: 1,
            		    maxDate : "0",
            		    onClose: function( selectedDate ) {
            		    }
                });*/
            }
            
            if(clazz && clazz.indexOf('acc-delete-row') > 0){
            	el.on("click",deleteRowOdsProject);
            }else{
            	 el.attr('name', finalName);
                 el.attr('value','');
            }
        }
       
    });
    $clone.find('input:text').val('');
    $clone.find('textarea').val('');

   
    $(lastTr).closest('table').append($clone);
    


}
			
	$("#tbl-ods-projects").find(".date-picker").removeClass('hasDatepicker').datepicker({
		 changeMonth: true,
  		    numberOfMonths: 1,
  		    maxDate : "0",
  		    onClose: function( selectedDate ) {
  		    }
   });
}


function addMoreRisks() {
	
	$('#tabs .nav-tabs a:first').tab('show'); 
	
	
	var allTrs = $("#tbl-risks").find('tr');
	console.log(allTrs.length);
	if(allTrs.length == 1){
		$('#tbl-risks tbody').append('<tr><td></td><td><input class="form-control date-picker-txtRaisedDate txtRaisedDate" required="required" type="text" id="risks[0].raisedDate" name="risks[0].raisedDate"  /></td>'+
				'<td><textarea  rows="10" cols="50" class="form-control txtName" type="text" id="risks[0].name" name="risks[0].name"/></td>'+
				'<td><input class="form-control txtOwner" type="text" id="risks[0].owner" name="risks[0].owner" /></td>'+
				'<td><input class="form-control date-picker-txtTargetDate txtTargetDate" required="required" type="text" id="risks[0].targetDate" name="risks[0].targetDate" /></td>'+
				'<td><textarea rows="10" cols="50" class="form-control txtRickImpact" type="text" id="risks[0].impact" name="risks[0].impact" /></td>'+
				'<td><textarea rows="10" cols="50" class="form-control txtRiskMitigationStrategy" type="text" id="risks[0].mitigationStrategy" name="risks[0].mitigationStrategy" /></td>'+
				'<td><input class="form-control status" type="hidden" id="risks[0].status" name="risks[0].status" value="Open"/><button type="button" value="Delete" id="risks[0].delete" class="btn btn-default width100 pull-right risk-delete-row" onclick="deleteRowRisk(this)" ><i class="fa fa-trash" aria-hidden="true"></i> </button></td></tr>');
	
		$("#risks[0]-delete").click(deleteRowRisk);
	}else{		
	var lastTr = allTrs[allTrs.length-1];
	var $clone = $(lastTr).clone();
    $clone.find('input:text').val('');
    $clone.find('input:text').removeAttr('disabled');
    $clone.find('textarea').val('');
    $clone.find('textarea').removeAttr('disabled');
    $(lastTr).closest('table').append($clone);
    $clone.find('td').each(function(){
        var el = $(this).find(':first-child');
        var el2 = $(this).find(':last-child');
        var id = el.attr('id') || null;
        var id2 = el2.attr('id') || null;
        if(id) {
        	var idParts = id.split('.');
        	
	        	var idx = parseInt(idParts[0].substring(idParts[0].indexOf('[')+1,idParts[0].indexOf(']')));
	        	idx = idx + 1;
	        	
	        	var finalName ='risks[' + idx + '].' + idParts[1];
	        	el.attr('id', finalName);
	            
	            /*delete button */
	            var clazz = el.attr('class');
	            
	            if(clazz.indexOf('date-picker') > 0){
	            	$(el).datepicker({
	            		 changeMonth: true,
	            		    numberOfMonths: 1,
	            		    maxDate : "0",
	            		    onClose: function( selectedDate ) {
	            		    }
	                });
	            }
	            
	            if(clazz && clazz.indexOf('risk-delete-row') > 0){
	            	el.on("click",deleteRowRisk);
	            }else{
	            	el.attr('name', finalName);
	            	if(idParts[1] == "id"){
	            		el.attr('value',0);
	            	}else{
	            		el.attr('value',el.attr('value'));
	            	}
	            }
        	
        }
        if(id2) {
        	var idParts = id2.split('.');
        	if(idParts[1] == "delete"){
        		var idx = parseInt(idParts[0].substring(idParts[0].indexOf('[')+1,idParts[0].indexOf(']')));
	        	idx += 1;
	        	var finalName ='risks[' + idx + '].' + idParts[1];
	        	el2.attr('id', finalName);
	        	el2.removeAttr("onclick");
        		el2.attr("onclick","deleteRowRisk(this)"); 
        		el2.children().remove();
        		el2.append("<i class='fa fa-trash' aria-hidden='true'></i>");
        		
            }
        }
        
       
    });

}

$("#tbl-risks").find(".date-picker-txtRaisedDate").removeClass('hasDatepicker').datepicker({
		 changeMonth: true,
 		    numberOfMonths: 1,
 		    maxDate : "0",
 			dateFormat: "dd-M-yy",
 		    onClose: function( selectedDate ) {
 		    	//$("#tbl-risks").find( ".date-picker-txtTargetDate" ).datepicker( "option", "minDate", selectedDate );	    	
 		    }
  });


$("#tbl-risks").find(".date-picker-txtTargetDate").removeClass('hasDatepicker').datepicker({
	    changeMonth: true,
	    numberOfMonths: 1,	   
		dateFormat: "dd-M-yy",
	    onClose: function( selectedDate ) {
	    }

});  


	/*$("#").datepicker({
		 changeMonth: true,
		    numberOfMonths: 1,
		    maxDate : "0",
			dateFormat: "yy-mm-dd",
		    onClose: function( selectedDate ) {
		    }
 });*/

	/* function mbox (message, title) {
         BootstrapDialog.show({
             title: title || 'Message',
             message: message
         });
     }*/
}