$(window).load(function() {
	 var selectedPageUrl = window.location.href; 
	 $('.navbar-inverse ul li a').filter(function() { 
	     return $(this).prop('href') === selectedPageUrl;
	 }).parent('li').addClass('active').closest('.response-dd').addClass('active');
});
$(document).ready(function () {
			 
	 $('.nav-tabs').on('shown.bs.tab', 'a', function(e) {
	       // console.log(e.relatedTarget);
	        if (e.relatedTarget) {
	            $(e.relatedTarget).removeClass('active');
	        }
	    });
});
