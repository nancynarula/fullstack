"use strict";
var contextPath = "/test";
var ods = ods || {};
ods.remoting = (function($){
	
	var self = {};
	var defaultConfig = {};    	
	
	  self.get = function(url, data, dataType){
			 return $.ajax({
				 url : url,
				 data : data,
				 dataType : dataType,
				 type : "GET"
			 });  
	  },
	  self.post = function(url, data, dataType){
			  return $.ajax({
				 url : url,
				 data : data,
				 dataType : dataType,
				 type : "POST"
			  });  
	  },
	  self.getJSON = function(url, data){
		  return this.get(url, data, "json");
	  },
	  self.postJSON = function(url, data){
		  return this.post(url, data, "json");
	  }
	  
	  self.executeGet = function(url, dataType, successCallBack, errorCallback) {
		  $.ajax({
				 url : url,
				 dataType : dataType,				 
				 type : "GET"
		  })
		  .success(function(respData, textStatus, jqXHR) {
			  if(successCallBack && typeof successCallBack === "function") {
				  successCallBack.call({}, respData);
			  } else {
				  console.log("Execute get - successCallBack Undefined");
			  }
			  
		  })
		  .error(function(jqXHR, textStatus, errorThrown) {
			  if(errorCallback && typeof errorCallback === "function") {
				  errorCallback.call({}, jqXHR, textStatus, errorThrown);
			  } else {
				  console.log("Execute get - errorCallback Undefined");
			  }
			  
		  });
	  };
	  
	  self.executePost = function(url, postData, dataType, contentType, successCallBack, errorCallback) {
		  $.ajax({
				 url : url,
				 data : postData,
				 dataType : dataType,
				 contentType : contentType,
				 type : "POST"
		  })
		  .success(function(respData, textStatus, jqXHR) {
			  if(successCallBack && typeof successCallBack === "function") {
				  successCallBack.call({}, respData);
			  } else {
				  console.log("Execute post - successCallBack Undefined");
			  }
		  })
		  .error(function(jqXHR, textStatus, errorThrown) {
			  if(errorCallback && typeof errorCallback === "function") {
				  errorCallback.call({}, jqXHR, textStatus, errorThrown);
			  } else {
				  console.log("Execute post - errorCallback Undefined");
			  }
		  });
	  };
	  
	  self.executePost = function(url, encType, postData, contentType, cacheType, processDataType, successCallBack, errorCallback) {
		  $.ajax({
				 url : url,
				 enctype:encType,
				 data : postData,
				 contentType : contentType,
				 cache:cacheType,
				 processData:processDataType,
				 type : "POST"
		  })
		  .success(function(respData, textStatus, jqXHR) {
			  if(successCallBack && typeof successCallBack === "function") {
				  successCallBack.call({}, respData);
			  } else {
				  console.log("Execute post - successCallBack Undefined");
			  }
		  })
		  .error(function(jqXHR, textStatus, errorThrown) {
			  if(errorCallback && typeof errorCallback === "function") {
				  errorCallback.call({}, jqXHR, textStatus, errorThrown);
			  } else {
				  console.log("Execute post - errorCallback Undefined");
			  }
		  });
	  };
	  
	return self;
})($);

ods.utils = (function($){
	var self = {};

	  self.redirect = function(url){
			window.location.href = url; 
	  }
   return self;
})($);


$.fn.serializeObject = function() {
       var o = {};
       var a = this.serializeArray();
       $.each(a, function() {
           if (o[this.name]) {
               if (!o[this.name].push) {
                   o[this.name] = [o[this.name]];
               }
               o[this.name].push(this.value || '');
           } else {
               o[this.name] = this.value || '';
           }
       });
       return o;
   };

//common dialog function
function commonDialog(titlemsg,bodytxt,yesOpt,noOpt){
     $('<div style="z-index:99999;"></div>')
        .appendTo('body')
        .html('<br><div id="dialogBody" class="warning-msg-txt">'+bodytxt+'</div>')
        .dialog({
            modal: true
            , title: titlemsg
            , zIndex: 9999
            , autoOpen: true
            , width: 'auto'
            , resizable: false
            , buttons: {
                Yes: function() {
                    yesOpt();
                     $(this).remove();
                },
                No: function(){
                    noOpt();
                      $(this).remove();
                }
            }
            , close: function(
                event, ui) {
                $(this).remove();
            }
        });
        if(titlemsg =="Error"){
            $("#dialogBody").removeClass("warning-msg-txt");
            $("#dialogBody").addClass("error-msg-txt");
        }
}


function commonDialogOk(titlemsg,bodytxt,okOpt){
        $('<div style="z-index:99999;"></div>')
           .appendTo('body')
           .html('<br><div id="dialogBody" class="warning-msg-txt">'+bodytxt+'?</div>')
           .dialog({
               modal: true
               , title: titlemsg
               , zIndex: 9999
               , autoOpen: true
               , width: 'auto'
               , resizable: false
               , buttons: {
                   Ok: function() {
                       
                        $(this).remove();
                        okOpt();
                   }
               }
               , close: function(
                   event, ui) {
                   $(this).remove();
               }
           });
           if(titlemsg =="Error"){
               $("#dialogBody").removeClass("warning-msg-txt");
               $("#dialogBody").addClass("error-msg-txt");
               }
}

function customDialog(message, title,okOpt,cancleOpt){
	   BootstrapDialog.show({
        title: title || 'Message',
        closable: false,
        message: message,
        buttons: [{
            label: 'Ok',
            action: function(dialog) {
            	dialog.close();
            return okOpt();
            }
        },{
            label: 'Cancel',
            action: function(dialog) {
            	dialog.close();
         	   return cancleOpt();
            }
        }]
    });
}



