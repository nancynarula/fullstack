
var TaskForPortfolioPageScript = function () {
    var variable = {
        url_data_for_portfolio: contextPath + "/reports/data-for-portfolio",
        chartWidth: "100%",
		chartDefaultHeight: 650,
        chartHeight: 650,
        eod: {hour:23, minute:59, second:59} //End of Day for momentjs


    };
    var selector = {
        chart: "#chart",
        date_pickers: ".datepicker",
        frm_search_filter: "#frmSearchFilter"
    };

    var fn = {
        init: function () {
        	fn.initDefaultFilters();
            fn.initDatePickers();
            fn.initSearchFilterForm();
        },
        initDatePickers: function () {
            $(selector.date_pickers).datepicker({
            	 dateFormat: 'yy-mm-dd'
            }).on('changeDate', function (e) {
                $(this).datepicker('hide');
            });
        },
        initDefaultFilters: function() {
        	var frm = $(selector.frm_search_filter);
        	
        	var currentYear = (new Date()).getFullYear();
        	var statDate = moment().subtract(1, 'months').format("YYYY-MM-DD");
        	var endDate = moment(statDate).add(2, 'months').format("YYYY-MM-DD");
        	
        	frm.find("#dtpStartDate").val(statDate);
        	frm.find("#dtpEndDate").val(endDate);
        	$("#ddlPortfolioId").select2();
        },
        initSearchFilterForm: function () {
            var frm = $(selector.frm_search_filter);
            frm.submit(function () {
            	fn.doSearchFilterFormSubmit.call(this);
                return false;
            });
        },
        doSearchFilterFormSubmit: function() {
        	var frm = $(this);
        	var portfolioId = frm.find("#ddlPortfolioId").val();
        	var startDate = frm.find("#dtpStartDate").val();
        	var endDate = frm.find("#dtpEndDate").val();
        	if(portfolioId == ""){
        		fn.mbox("Please select portfolio.")
        		return false;
        	}
        	if((startDate == "")||(endDate == "")){
        		fn.mbox("Please select Date.")
        		return false;
        	}
        	if(endDate <= startDate){
        		fn.mbox("End Date Must be greater than Start Date.")
        		return false;
        	}
        	fn.fetchAndRenderChart(portfolioId, startDate, endDate);
        	
        	return false;
        },
        fetchAndRenderChart: function(portfolioId, startDate, endDate) {
        	startDate = startDate || "2017-01-01";
        	endDate = endDate || "2017-12-12";
        	
        	if(startDate != "") {
        		startDate = moment(startDate).format("YYYY-MM-DD"); 
        	}
        	if(endDate != "") {
        		endDate = moment(endDate).format("YYYY-MM-DD");
        	}
        	
        	var postData = $.param({
        		portfolioName: portfolioId,
        		startDate: startDate,
        		endDate: endDate
        	});
        	
        	var url = variable.url_data_for_portfolio + "?" + postData;
        	ods.remoting.executeGet(url, "JSON", function(response) {
        		var chartDataRaw = response;
        		variable.startDate = startDate,
                variable.endDate = endDate
                
        		var chartData = fn.transposeChartDataForFusionCharts(chartDataRaw);
                fn.renderChart(chartData);
        	}, function (jqXHR, status, err) {
            	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
            		fn.mbox(jqXHR.responseJSON.message, "Error");
            		return false;
            	}
            	fn.mbox("failure", "Error");
            });
        },
        renderChart: function (chartData) {
            FusionCharts.ready(function () {
            	var totalRows = 2;
		    	if(chartData.processes && chartData.processes && chartData.processes.process.length > 0) {
		    		totalRows = chartData.processes.process.length  + 1; //one extra header row
		    	} 
		    	var headerHeight = 50;
		        var rowHeight = 25;
		        var totalHeight = (totalRows*rowHeight) + headerHeight;
		        var chartHeight = Math.min(totalHeight, variable.chartDefaultHeight);
		        variable.chartHeight = chartHeight;
                var fusioncharts = new FusionCharts({
                    type: 'gantt',
                    renderAt: 'chart-container',
                    width: variable.chartWidth,
		            height: chartHeight,
                    dataFormat: 'json',
                    dataSource: chartData
                });
                fusioncharts.render();
            });
        },
        transposeChartDataForFusionCharts: function(data) {
        	var weekends = data.weekends;
        	var portfolio = data.portfolio || {};
        	var allProjects = portfolio.projects || [];
        	
            var chartData = fn.getEmptyChartData();
        	
        	var chartProcesses = [];
        	var chartActivity = [];
        	var chartTasks = [];
        	var milestoneCheck = [];
            var filterdCategory = fn.generateDateRangeCategoriesForFusionChart(weekends);
            	
            var count = 0;
            var countSecond = 0;
            var countM = 0;

        	var previousProcessName = null;
            _.forEach(allProjects, function (project, index, all) {
            	var rowIndex = 0;
                var projectId = project.id;
                var projectName = project.name;
                var allMilestones = project.milestones;
                
            	_.forEach(allMilestones, function(milestone, index, all) {
	                //First Column - Project
            		var milestoneId = milestone.id;
            		var milestoneName = milestone.name;
	                var keyChartProcessid = 'prj_miletone_' + projectName + "_" + milestoneName;
	                var keyProgramDisplayText = (rowIndex == 0) ? projectName : "";
	                var objProcess = {
	                    label: keyProgramDisplayText,
	                    id: keyChartProcessid
	                };
	                chartProcesses.push(objProcess);
	
	                //2nd column - Milestone
	                var objActivity = {
	                    label: milestone.name,
	                };
	                chartActivity.push(objActivity);
	
	
	            	//milestone stories
	                var taskFinishDateMoment = moment(milestone.projectedEndDate);
                    var taskStartDate = moment(milestone.startDate).format("MM/DD/YYYY");
                    var taskFinishDate = taskFinishDateMoment;
                    var phaseTooltext = [
        				"Start Date: " + taskStartDate,
        				"Projected End Date: " + taskFinishDate.format("MM/DD/YYYY"),
        				"Name: " + milestone.name,
        				"Summary: " + milestone.summary,
        				"Status: " + milestone.status,
        				"Completion: " + (milestone.percentageCompletion||0) + "%"
					].join("<br/>");
		
                    var taskColor = fn.getBarColor(milestone);
                    var chartTaskForPhase = {
	                    id: 'PRJ' + countSecond,
	                    processid: keyChartProcessid,
	                    start: taskStartDate,
	                    end: taskFinishDate.set(variable.eod).toDate(),
	                    color: taskColor,
	                    label: milestone.name,
	                    tooltext: phaseTooltext
                    };
                    chartTasks.push(chartTaskForPhase);
                    countSecond++;
                    
                    countM++;

	                rowIndex++;
            	});	
            	
            	
                previousProcessName = projectName;
            });

            chartData.processes.process = chartProcesses;
            chartData.datatable.datacolumn[0].text = chartActivity;
            chartData.tasks.task = chartTasks;
            chartData.milestones.milestone = milestoneCheck;
            chartData.categories[0].category = filterdCategory;
            chartData.categories = filterdCategory;
                
            console.log("chartProcesses: ", chartProcesses);
            console.log("chartActivity: ", chartActivity);
            console.log("chartTasks: ", chartTasks);
            console.log("chartMilestone: ", milestoneCheck)
        	
        	
        	if(chartData.datatable.datacolumn[0].text.length == 0) {
        		delete chartData.datatable.datacolumn;
        	}
        	console.log(chartData);
        	return chartData;
        },
        generateDateRangeCategoriesForFusionChart: function(weekends) {
        	var result = [];
        	var years = [];
        	var weekDays = [];
        	var weeks = [];
        	
        	$.each(weekends, function(key, dates) {
        		var weekNumber = key;
        		var minDate = _.min(dates);
        		var maxDate = _.max(dates);
        		
        		var start = moment(minDate);
        		var end = moment(maxDate).set(variable.eod);
        		var weekItem = {
    				"start":  start.toDate(),
                    "end":  end.toDate(),
                    "label": "W: " + end.format("M/D")
        		};
        		weeks.push(weekItem);
        		
        		/*for(var i=0 ; i<dates.length ; i++) {
        			var item = dates[i];
        			var dt = moment(item).format("MM/DD/YYYY");
        			var day = moment(item).format("DD");
        			weekDays.push({ "start": dt, "end": dt, "label": day });
        		}*/
        	});
        	
            result.push({ category: weeks});
        	//result.push({ category: weekDays});
            	
        	return result;
        },
        getBarColor: function(milestone) {
        	var green = "#6caa03";
        	var chartColor = green;
        	if(milestone.costOvershoot == true) {
        		chartColor = "#e44b02";
        	}
        	return chartColor;
        },
    	getEmptyChartData: function() {
        	
        	var chartData = {
                "chart": {
                    "dateformat": "mm/dd/yyyy",
                    "outputdateformat": "mm/dd",
                    "caption": "",
                    "captionFontSize": "14",
                    "subCaption": "",
                    "subCaptionFontSize": "12",
                    /*"ganttPaneDuration": "8",
                    "ganttPaneDurationUnit": "y",*/
                    
                    //"palette": "2",
                    "showLegend": "0",
                    "captionFontSize": "14",
                    "subCaptionFontSize": "12",
                    "labelDisplay": "wrap",
                    //"forceRowHeight": "1",
                    "scrollShowButtons": "1",
                    "showFullDataTable": "0",
                    "legendPosition": "top",
                    "legendAllowDrag": "1",
                    "plottooltext": "<div id='nameDiv'>Start Date - $start <br> End Date - $end</div>",
                    "milestoneFont": "Times New Roman",
                    "milestoneFontSize": "15",
                    "exportEnabled": "0",
                    "exportFormats": "PDF=Export As PDF|JPG=Export As JPG",
                    "dataEmptyMessage": "No Data Found",
                    "dataInvalidMessage": "No Data Found",
                    "taskBarFillMix": "light+0"
                },
                "categories": [{
                	"bgcolor": "#999999",
                    "category": []
                }],
                "processes": {
                    "fontsize": "12",
                    "isbold": "1",
                    "align": "left",
                    "headerbgcolor": "#ffffff",
                    "headertext": "",
                    "headerfontsize": "14",
                    "headervalign": "middle",
                    "headeralign": "left",
                    "process": []
                },
                "datatable": {
                    "showprocessname": "1",
                    "namealign": "left",
                    "fontcolor": "#000000",
                    "fontsize": "10",
                    "valign": "middle",
                    "align": "left",
                    "headervalign": "bottom",
                    "headeralign": "center",
                    "headerbgcolor": "#ffffff",
                    "headerfontcolor": "#000000",
                    "headerfontsize": "12",
                    "datacolumn": [{
                        "headertext": "Activity",
                        "text": []
                    }]
                },
                "tasks": {
                    "showlabels": "1",
                    "showstartdate": "1",
                    "showenddate": "1",
                    "task": []
                },
                "milestones": {
                    "milestone": []
                }
            };
        	chartData.processes.process = []; //empty, it as we will populate it dynamically
        	chartData.datatable.datacolumn[0].text = []; //empty it as we will populate it dynamically
        	return chartData;
        },
        mbox: function (message, title) {
            BootstrapDialog.show({
                title: title || 'Message',
                message: message
            });
        }
    };
    return {
        init: function () {
            fn.init();
        }
    };

}();

jQuery(document).ready(function ($) {
    $(function () {
    	TaskForPortfolioPageScript.init();
    });
});