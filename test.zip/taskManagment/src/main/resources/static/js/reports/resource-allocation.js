
var ResourceAllocation = function () {
    var variable = {
        url_data_for_resource: contextPath + "/reports/data-for-resourceAllocation",
        url_get_projects: contextPath + "/project/get-active-projects/",
        url_get_resources: contextPath + "/user-management/reporting-resources",
        reportData: {},
        chartWidth: "100%",
		chartDefaultHeight: 650,
        chartHeight: 650,
        eod: {hour:23, minute:59, second:59} //End of Day for momentjs

    };
    var selector = {
        chart: "#chart",
        grid: "#grid",    
        date_pickers: ".datepicker",
        frm_search_filter: "#frmSearchFilter",
        btn_export_report: ".btnExportReport",
        previous_week : "#weekSelectionPrevious",
        next_week : "#weekSelectionNext",
        refresh_grid_filter : "#reset-filter-grid",         
        date_add_edit_item: "#date", 
        modal:"#modal",
        all_users : []
    };

    var fn = {
    		 init: function () {
    	        	fn.initDefaultFilters();
    	            fn.initDatePickers();
    	                   
    	        },
    	        loader : function (target) {
                    var element = $(target);
                    kendo.ui.progress(element, true);
                   /* setTimeout(function(){
                        kendo.ui.progress(element, false);
                    }, 2000);  */      
                },
    	        initDatePickers: function () {
    	            $(selector.date_pickers).datepicker({
    	            	dateFormat: 'dd-M-yy'
    	            }).on('changeDate', function (e) {
    	                $(this).datepicker('hide');
    	            });
    	        },
    	        
    	        initDefaultFilters: function() {
    	        	var frm = $(selector.frm_search_filter);     	
    	        	
    	        	var statDate = moment().startOf('month').format("DD-MMM-YYYY");
    	        	var endDate="";
    	        	//var endDate =  moment().endOf('month').format("DD-MMM-YYYY"); 
    	        	
    	        	frm.find("#dtpStartDate").val(statDate);
    	        	frm.find("#dtpEndDate").val(endDate);
    	        	var resourcesUrl = variable.url_get_resources;
    	        	var projectsUrl = variable.url_get_projects;
    	        	var resources;
    	        	var projects ;
    		
    	        	ods.remoting.executeGet(resourcesUrl, "JSON", function(response) {
    	        		if(response.status != "SUCCESS") {
    	        			fn.mbox(response.message,"Error");
    	        			return false;
    	        		}
    	        		resources= response.responseData;
    		
    			
    	        	ods.remoting.executeGet(projectsUrl, "JSON", function(response1) {
    	        		if(response.status != "SUCCESS") {
    	        			fn.mbox(response1.message,"Error");
    	        			return false;
    	        		}
    	        		projects = response1.responseData;
            		
    	        		$.each(projects , function(index, value){
    	        			$("#project").append('<option value="'+value.id+'">'+value.name+'</option>');
    	        		});
    	        		
    	        		$.each(resources , function(index, value){
    	        			$("#resource").append('<option value="'+value.id+'">'+value.displayName+'</option>');
    	        		});
                    
            fn.initButtonClicks();
    			
    		}, function (jqXHR, status, err) {
                	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                		fn.mbox(jqXHR.responseJSON.message, "Error");
                		return false;
                	}
                	fn.mboxError("failure", "Error");
                });
        
         fn.initButtonClicks();
        	
    
        });
        },
          
        bindGrid: function (result) {
        	var grid = $(selector.grid).kendoGrid({
        	    dataSource: {
        	        data: result,            	       
        	        pageSize: 20,
        	        schema: {
        	            data: function(data) {
							for (var i = 0; i < data.length; i++) {
								var item = data[i];
							
								if (item.allocationStartDateStr) {
									item.allocationStartDateStr = new Date(
											item.allocationStartDateStr);
								}
								if (item.allocationEndDateStr) {
									item.allocationEndDateStr = new Date(
											item.allocationEndDateStr);
								}
								
								
							}
							return data;
						}
        	        }
        	    },
        	    toolbar: ["excel"],
                excel: {
                    fileName: "Resource Allocation Data.xlsx",  
                    proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
                    filterable: true
                },
        	    filterable: true,
        	    groupable: false,
                sortable: true,
                scrollable: true,
        	    serverPaging: false,
        	    serverSorting: false,
        	    serverFiltering: false,
        	    pageable: {
        	        refresh: false,
        	        pageSizes: true,
        	        buttonCount: 5
        	    },
        	   
                dataBound: function() {
                    this.expandRow(this.tbody.find("tr.k-master-row").first());
                },
        	    columns: [
        	        {
        	            field: "name",
        	            title: "Resource Name",
        	            filterable: {
        	                multi: true,
        	                search: true
        	            },
        	            width:100
        	        },
        	        {
        	        	field: "projectName",
        	            title: "Project Name",
        	            filterable: {
        	                multi: true,
        	                search: true
        	            },
        	           
        	            width:100
        	        },            	    
        	        {
        	            field: "allocationPercentage",
        	            filterable: {
        	                multi: true,
        	            },
        	            attributes: {
                         	"class": "ele-txtRight"
                        },
        	            title: "Allocation Percentage",
        	            width:100
        	           
        	        },
        	        {
        	            field: "allocationStartDateStr",
        	            format: "{0:dd-MMM-yyyy}",
        	            type: "date",
        	            filterable: {
        	                ui: "datepicker"
        	            },
        	            attributes: {
                         	"class": "ele-txtRight"
                        },
        	            title: "Allocation Date From",
        	            width:100
        	            
        	        }, 	  
        	        {
        	            field: "allocationEndDateStr",
        	            format: "{0:dd-MMM-yyyy}",
        	            type: "date",
        	            filterable: {
        	                ui: "datepicker"
        	            },
        	            attributes: {
                         	"class": "ele-txtRight"
                        },
        	            title: "Allocation Date To",
        	            width:100
        	            
        	        }
        	    ],
        	     dataBound: function(e) {
        	    	// $("#grid").find(".k-pager-wrap").hide();           	    	  
        	    	//Selecting Grid
        	    	 var entityGrid = $("#grid").data("kendoGrid");
        	    	 //Getting row item
        	    	 var dataentityGrid = entityGrid.dataSource.data();          	    	
        	    	            	    
        	    	$("#grid tbody tr.k-master-row").each(function (index,value) {
      	    	        var currentDataItem = $("#grid").data("kendoGrid").dataItem($(value).closest("tr"));          	    	        	
      	    	                 	    	        	
       	    	        //Check in the current dataItem for the removal of the expand-collapse trigger.
      	    	        if (currentDataItem.isChildExist != true) {
      	    	            $(value).find("a.k-icon.k-i-expand").remove();
       	    	        }
      	    	    });          	    	  
                    }
        	}).data("kendoGrid");
        	
        	kendo.ui.progress($(document.body), false);

        },
        
        initButtonClicks: function(){
        	
        	$(selector.frm_search_filter).submit(function(){
        		var frm = $(this);
        		fn.loader(document.body);
        			var projectId = frm.find("#project").val();
        			var resourceId = frm.find("#resource").val();            	
              	
        			var startDate = frm.find("#dtpStartDate").val();
          			var endDate = frm.find("#dtpEndDate").val();            	
                	
                	if(startDate != "") {
                		startDate = moment(startDate).format("DD-MMM-YYYY").toString(); 
                	}
                	if(endDate != "") {
                		endDate = moment(endDate).format("DD-MMM-YYYY").toString();
                	}
                	
              	var postData = $.param({
              		startDate: startDate,
              		endDate: endDate,
              		projectId:projectId,
              		resourceId:resourceId
              		
              	});            	
              				
              	var fetchdata = variable.url_data_for_resource + "?" + postData; 
               	ods.remoting.executeGet(fetchdata, "JSON", function(response) {    
               		 $(selector.grid).html("");
               		fn.bindGrid(response.responseData);
               	}, function (jqXHR, status, err) {
                   	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                   		fn.mbox(jqXHR.responseJSON.message, "Error");
                   		return false;
                   	}
                    kendo.ui.progress($(document.body), false);
                   	fn.mbox("failure", "Error");
                   });             	
                 return false;
              });
          
        },
        mbox: function (message, title) {
            BootstrapDialog.show({
                title: title || 'Message',
                message: message,
                buttons: [{
                    label: 'Ok',
                    action: function(dialog) {
                    	/*var base_url = window.location.origin + "/pm-tool/timecard/managerview";
            			window.location.href= base_url*/
                    }
                }]
            });
        }
    };        
    return {
        init: function () {
            fn.init();
        }
    };
}();

       
    
  


jQuery(document).ready(function ($) {
    $(function () {
    	ResourceAllocation.init();
    });
});