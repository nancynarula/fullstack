
var TimesheetReportPageScript = function () {
    var variable = {
        url_data_for_timesheet: contextPath + "/reports/data-for-timesheet"  ,  
        reportType: ""   

    };
    var selector = {        
        date_pickers: ".datepicker",
        frm_search_filter: "#frmSearchFilter",
        grid: "#grid",  
        refresh_grid_filter : "#reset-filter-grid"
    };

    var fn = {
        init: function () {
        	fn.initDefaultFilters();
            fn.initDatePickers();
            fn.initSearchFilterForm();         
        },
        
        loader : function (target) {
            var element = $(target);
            kendo.ui.progress(element, true);
           /* setTimeout(function(){
                kendo.ui.progress(element, false);
            }, 2000);  */      
        },
        
        initDatePickers: function () {
            $(selector.date_pickers).datepicker({
            	dateFormat: 'yy-mm-dd'
            }).on('changeDate', function (e) {
                $(this).datepicker('hide');
            });
        },
        initDefaultFilters: function() {
        	var frm = $(selector.frm_search_filter);     	
        	
        	var statDate = moment().startOf('week').format("YYYY-MM-DD");
        	var endDate =  moment().endOf('week').format("YYYY-MM-DD"); 
        	
        	frm.find("#dtpStartDate").val(statDate);
        	frm.find("#dtpEndDate").val(endDate);
        },
        initSearchFilterForm: function () {
            var frm = $(selector.frm_search_filter);
            frm.submit(function (e) { 
            	
            	fn.loader(document.body);
            	
            	var validatorForm = $(selector.frm_search_filter).kendoValidator().data("kendoValidator");
                validatorForm.validate();
            	var frm = $(selector.frm_search_filter);   
      			var startDate = frm.find("#dtpStartDate").val();
      			var endDate = frm.find("#dtpEndDate").val();            	
            	var projectId = frm.find("#projectId").val(); 
            	var resourceId = frm.find("#resourceId").val(); 
            	         	
            	if($('#radio1').is(':checked')) 
            		reportType = 'summary';
            	else if($('#radio2').is(':checked')) 
            		reportType = 'detailed';            	
            	
//            	reportType = 'detailed';
            	if(startDate != "") {
            		startDate = moment(startDate).format("YYYY-MM-DD"); 
            	}
            	if(endDate != "") {
            		endDate = moment(endDate).format("YYYY-MM-DD");
            	}
            	
            	var postData = $.param({
            		startDate: startDate,
            		endDate: endDate,
            		resourceId: resourceId,
            		projectId : projectId,
            		reportType: reportType
            	});            	
            				
            	var fetchdata = variable.url_data_for_timesheet + "?" + postData; 
             	ods.remoting.executeGet(fetchdata, "JSON", function(response) {    
             		 $(selector.grid).html("");
             		fn.bindGrid(response.responseData);
             	}, function (jqXHR, status, err) {
                 	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
                 		fn.mbox(jqXHR.responseJSON.message, "Error");
                 		 kendo.ui.progress($(document.body), false);
                 		return false;
                 	}
                 	
                 	fn.mbox("failure", "Error");
                 });             	
               return false;
            });
        }, 
        bindGrid: function (result) {
        	
        	var tempColl = [];
        	if(reportType =="summary"){
        		tempColl =  [
      	        {
      	            field: "projectName",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            title: "Project",
      	            attributes: {
                       	"class": "ele-txtLeft"
                      },
      	            filterable: {
      	                multi: true,
      	                search: true
      	            },
      	            width:80
      	        },
      	        {
      	            field: "userName",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            	attributes: {
                           	"class": "ele-txtLeft"
                          },
      	            filterable: {
      	                multi: true,
      	            },
      	            
      	            title: "Resource ",            	            
      	            width:50          	            
      	        },     
      	       /* {
      	            field: "loggedForDateStr",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            filterable: {
      	                multi: true,
      	            },
      	            attributes: {
                       	"class": "ele-txtLeft"
                      },
      	            title: "Date",
      	           // hidden: '#if(reportType == "summary") {# true # }  else {# false #}#',
      	            width:50           	            
      	        }, 	 */ 
      	        {
      	            field: "hours",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            filterable: {
      	                multi: true,
      	            },
      	            attributes: {
                       	"class": "ele-txtRight"
                      },
      	            title: "Hours Logged",
      	            width:30
      	          
      	        },
      	        {
      	            field: "allocatedHours",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            filterable: {
      	                multi: true,
      	            },
      	            attributes: {
                       	"class": "ele-txtRight"
                      },
                      //hidden: '#if(reportType == "detailed") {# true # }  else {# false #}#',
      	            title: "Allocated Hours",
      	            width:30
      	          
      	        }
      	          	       
      	    ]
        	}else if(reportType=="detailed"){
        	tempColl= [
      	        {
      	            field: "projectName",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            title: "Project",
      	            attributes: {
                       	"class": "ele-txtLeft"
                      },
      	            filterable: {
      	                multi: true,
      	                search: true
      	            },
      	            width:80
      	        },
      	        {
      	            field: "userName",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            	attributes: {
                           	"class": "ele-txtLeft"
                          },
      	            filterable: {
      	                multi: true,
      	            },
      	            
      	            title: "Resource ",            	            
      	            width:50          	            
      	        },     
      	        {
					 field : "loggedForDateStr",
					headerAttributes : {
						style : "text-align: left"
					},
					format : "{0:dd-MMM-yyyy}",
					type : "date",
					filterable : {
						ui : "datepicker"
					},
					attributes : {
						"class" : "ele-txtLeft"
					},
      	            title: "Date",
      	           // hidden: '#if(reportType == "summary") {# true # } else {#
					// false #}#',
      	            width:50           	            
      	        }, 	  
      	        {
      	            field: "hours",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            filterable: {
      	                multi: true,
      	            },
      	            attributes: {
                       	"class": "ele-txtRight"
                      },
      	            title: "Hours Logged",
      	            width:30
      	          
      	        }/*,
      	        {
      	            field: "allocatedHours",
      	            headerAttributes: {
      	            	style: "text-align: left"
      	            	},
      	            filterable: {
      	                multi: true,
      	            },
      	            attributes: {
                       	"class": "ele-txtRight"
                      },
                      //hidden: '#if(reportType == "detailed") {# true # }  else {# false #}#',
      	            title: "Allocated Hours",
      	            width:30
      	          
      	        }*/
      	          	       
      	    ]
        	}
        	
        	var grid = $(selector.grid).kendoGrid({ 
        	    dataSource: {
        	        data: result,            	       
        	        pageSize: 20,
        	        schema: {
        	            data: function(data) {            	            	

							for (var i = 0; i < data.length; i++) {
								var item = data[i];
							
								if (item.loggedForDateStr) {
									item.loggedForDateStr = new Date(
											item.loggedForDateStr);
								}
								
							}
							return data;
        	                
        	            }
        	        }
        	    },
        	    toolbar: ["excel"],
                excel: {
                    fileName: "Timesheet Data.xlsx",  
                   // proxyURL: "https://demos.telerik.com/kendo-ui/service/export",
                    filterable: true,
                    allPages: false
                },
        	    filterable: true,
        	    groupable: false,
                sortable: true,
                scrollable: true,
        	    serverPaging: false,
        	    serverSorting: false,
        	    serverFiltering: false,
        	    pageable: {
        	        refresh: false,
        	        pageSizes: true,
        	        buttonCount: 5
        	    },        	    
                dataBound: function() {
                    this.expandRow(this.tbody.find("tr.k-master-row").first());
                },
        	    columns:tempColl,
        	     dataBound: function(e) {
        	    	// $("#grid").find(".k-pager-wrap").hide();           	    	  
        	    	//Selecting Grid
        	    	 var entityGrid = $("#grid").data("kendoGrid");
        	    	 //Getting row item
        	    	 var dataentityGrid = entityGrid.dataSource.data();          	    	
        	    	            	    
        	    	$("#grid tbody tr.k-master-row").each(function (index,value) {
      	    	        var currentDataItem = $("#grid").data("kendoGrid").dataItem($(value).closest("tr"));
       	    	        //Check in the current dataItem for the removal of the expand-collapse trigger.
      	    	        if (currentDataItem.isChildExist != true) {
      	    	            $(value).find("a.k-icon.k-i-expand").remove();
       	    	        }
      	    	    });         	    	
        	    	
                    }
        	}).data("kendoGrid");        	
        	
        	var dataSourcePage = $(selector.grid).data("kendoGrid").dataSource,
            total = dataSourcePage.total();
         
        	dataSourcePage.pageSize(total);
        	dataSourcePage.bind("dataBound", function () {        		
                this.pager.element.hide();
        });
        	$(selector.refresh_grid_filter).click(function() {
        		// Clear the grid filters
        		var gridDataSource = $(selector.grid).data("kendoGrid").dataSource;
        		for (var i = 0; i < gridDataSource.options.fields.length - 1; i++) {
        			gridDataSource.filter({ field: gridDataSource.options.fields[i].field, value: "" });
        		}
        		gridDataSource.filter([]);
        	}); 
        	
        	kendo.ui.progress($(document.body), false);
        },
        mbox: function (message, title) {
            BootstrapDialog.show({
                title: title || 'Message',
                message: message
            });
        },
        
    };
    return {
        init: function () {
            fn.init();
        }
    };

}();

jQuery(document).ready(function ($) {
    $(function () {
    	TimesheetReportPageScript.init();
    });
});