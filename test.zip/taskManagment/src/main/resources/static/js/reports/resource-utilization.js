
var ResourceUtilizationPageScript = function () {
    var variable = {
        url_data_for_resource: contextPath + "/reports/data-for-resource-utilization",
        chartWidth: "100%",
		chartDefaultHeight: 650,
        chartHeight: 650	

    };
    var selector = {
        chart: "#chart",
        date_pickers: ".datepicker",
        frm_search_filter: "#frmSearchFilter",
        template_resource_utilization: "#tmplResourceUtilization",
        chart_container_wrap: "#chart-container"
    };

    var fn = {
        init: function () {
        	fn.initJsRenderFunctions();
        	fn.initDefaultFilters();
            fn.initDatePickers();
            fn.initSearchFilterForm();
            fn.doSubmitForm();
        },
        initDatePickers: function () {
            $(selector.date_pickers).datepicker({
            	dateFormat: 'yy-mm-dd'
            }).on('changeDate', function (e) {
                $(this).datepicker('hide');
            });
        },
        initDefaultFilters: function() {
        	var frm = $(selector.frm_search_filter);
        	
        	var currentYear = (new Date()).getFullYear();
        	var statDate = moment().subtract(1, 'months').format("YYYY-MM-DD");
        	var endDate = moment(statDate).add(2, 'months').format("YYYY-MM-DD");
        	
        	frm.find("#dtpStartDate").val(statDate);
        	frm.find("#dtpEndDate").val(endDate);
        },
        initJsRenderFunctions: function () {
            $.views.helpers({
                formatDate: function (date, format) {
                    if (date) {
                        return moment(date).format(format);
                    }
                    return "";
                },
                ifTrue: function (val, str, fail) {
                    if (val === true) {
                        return str;
                    }
                    return fail || "";
                },
                makeArray: function(obj, keyPropertyName, valuePropertyName) {
                	return fn.makeArray(obj, keyPropertyName, valuePropertyName);
                },
                stringify: function(obj) {
                	return JSON.stringify(obj);
                }
            });

        },
        initSearchFilterForm: function () {
            var frm = $(selector.frm_search_filter);
            frm.submit(function () {
            	fn.doSearchFilterFormSubmit.call(this);
                return false;
            });
        },
        doSubmitForm: function() {
        	$(selector.frm_search_filter).submit();
        },
        doSearchFilterFormSubmit: function() {
        	var frm = $(this);
        	var startDate = frm.find("#dtpStartDate").val();
        	var endDate = frm.find("#dtpEndDate").val();
        	if((startDate == "")||(endDate == "")){
        		fn.mbox("Please select Date.")
        		return false;
        	}
        	if(endDate <= startDate){
        		fn.mbox("End Date Must be greater than Start Date.")
        		return false;
        	}
        	fn.fetchAndRenderChart(startDate, endDate);
        	
        	return false;
        },
        fetchAndRenderChart: function(startDate, endDate) {
        	startDate = startDate || "2017-01-01";
        	endDate = endDate || "2017-12-12";
        	
        	if(startDate != "") {
        		startDate = moment(startDate).format("YYYY-MM-DD"); 
        	}
        	if(endDate != "") {
        		endDate = moment(endDate).format("YYYY-MM-DD");
        	}
        	
        	var postData = $.param({
        		startDate: startDate,
        		endDate: endDate
        	});
        	
        	var url = variable.url_data_for_resource + "?" + postData;
        	ods.remoting.executeGet(url, "JSON", function(response) {
        		var chartDataRaw = response;
        		variable.startDate = startDate,
                variable.endDate = endDate
                
        		var chartData = fn.transposeChartDataForFusionCharts(chartDataRaw);
                fn.renderChart(chartData);
        	}, function (jqXHR, status, err) {
            	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
            		fn.mbox(jqXHR.responseJSON.message, "Error");
            		return false;
            	}
            	fn.mbox("failure", "Error");
            });
        },
        renderChart: function (chartData) {
        	var viewData = chartData;
            var template = $.templates(selector.template_resource_utilization);
            var templateOutput = $(template.render(viewData));
            $(selector.chart_container_wrap).empty().append(templateOutput);
        },
        transposeChartDataForFusionCharts: function(data) {
        	var weekends = data.weekends;
        	var allResources = data.projectHoursByWeekAndResourceMap || [];
        	var chartData = {};
        	
            var weeks = fn.generateDateRange(weekends);
          
            chartData.weeks = weeks;
            chartData.resources = allResources;
        	return chartData;
        },
        generateDateRange: function(weekends) {
        	var weeks = [];
        	
        	$.each(weekends, function(key, dates) {
        		var weekNumber = key;
        		var minDate = _.min(dates);
        		var maxDate = _.max(dates);
        		
        		var weekItem = {
        			"weekNo": weekNumber,
    				"start":  moment(minDate).format("MM/DD/YYYY"),
                    "end":  moment(maxDate).format("MM/DD/YYYY"),
                    "label": "W: " + moment(maxDate).format("M/D")
        		};
        		weeks.push(weekItem);
        	});
        	return weeks;
        },
    	getEmptyChartData: function() {
        	
        	var chartData = {
                "chart": {
                    "dateformat": "mm/dd/yyyy",
                    "outputdateformat": "mm/dd",
                    "caption": "",
                    "captionFontSize": "14",
                    "subCaption": "",
                    "subCaptionFontSize": "12",
                    /*"ganttPaneDuration": "8",
                    "ganttPaneDurationUnit": "y",*/
                    
                    //"palette": "2",
                    "showLegend": "0",
                    "captionFontSize": "14",
                    "subCaptionFontSize": "12",
                    "labelDisplay": "wrap",
                    //"forceRowHeight": "1",
                    "scrollShowButtons": "1",
                    "showFullDataTable": "0",
                    "legendPosition": "top",
                    "legendAllowDrag": "1",
                    "plottooltext": "<div id='nameDiv'>Start Date - $start <br> End Date - $end</div>",
                    "milestoneFont": "Times New Roman",
                    "milestoneFontSize": "15",
                    "exportEnabled": "0",
                    "exportFormats": "PDF=Export As PDF|JPG=Export As JPG",
                    "dataEmptyMessage": "No Data Found",
                    "dataInvalidMessage": "No Data Found",
                    "taskBarFillMix": "light+0"
                },
                "categories": [{
                	"bgcolor": "#999999",
                    "category": []
                }],
                "processes": {
                    "fontsize": "12",
                    "isbold": "1",
                    "align": "left",
                    "headerbgcolor": "#ffffff",
                    "headertext": "",
                    "headerfontsize": "14",
                    "headervalign": "middle",
                    "headeralign": "left",
                    "process": []
                },
                "datatable": {
                    "showprocessname": "1",
                    "namealign": "left",
                    "fontcolor": "#000000",
                    "fontsize": "10",
                    "valign": "middle",
                    "align": "left",
                    "headervalign": "bottom",
                    "headeralign": "center",
                    "headerbgcolor": "#ffffff",
                    "headerfontcolor": "#000000",
                    "headerfontsize": "12",
                    "datacolumn": [{
                        "headertext": "Activity",
                        "text": []
                    }]
                },
                "tasks": {
                    "showlabels": "1",
                    "showenddate": "1",
                    "task": []
                },
                "milestones": {
                    "milestone": []
                }
            };
        	chartData.processes.process = []; //empty, it as we will populate it dynamically
        	chartData.datatable.datacolumn[0].text = []; //empty it as we will populate it dynamically
        	return chartData;
        },
        makeArray: function(obj, keyPropertyName, valuePropertyName) {
        	keyPropertyName = keyPropertyName || "key";
        	valuePropertyName = valuePropertyName || "value";
        	var result = _.map(obj, function(value, key, collection) {
        		var ret = {};
        		ret[keyPropertyName] = key;
        		ret[valuePropertyName] = value;
        		return ret;
        	});
        	return result;
        },
        mbox: function (message, title) {
            BootstrapDialog.show({
                title: title || 'Message',
                message: message
            });
        },
    };
    return {
        init: function () {
            fn.init();
        }
    };

}();

jQuery(document).ready(function ($) {
    $(function () {
    	ResourceUtilizationPageScript.init();

    });
});