
var TaskForResourcePageScript = function () {
    var variable = {
        url_data_for_resource: contextPath + "/reports/data-for-resource",
        reportData: {},
        chartWidth: "100%",
		chartDefaultHeight: 650,
        chartHeight: 650,
        eod: {hour:23, minute:59, second:59} //End of Day for momentjs

    };
    var selector = {
        chart: "#chart",
        date_pickers: ".datepicker",
        frm_search_filter: "#frmSearchFilter",
        btn_export_report: ".btnExportReport"
    };

    var fn = {
        init: function () {
        	fn.initDefaultFilters();
            fn.initDatePickers();
            fn.initSearchFilterForm();
            fn.doSubmitForm();
            fn.initExportReportButtons();
        },
        initDatePickers: function () {
            $(selector.date_pickers).datepicker({
            	dateFormat: 'yy-mm-dd'
            }).on('changeDate', function (e) {
                $(this).datepicker('hide');
            });
        },
        initDefaultFilters: function() {
        	var frm = $(selector.frm_search_filter);
        	
        	var currentYear = (new Date()).getFullYear();
        	var statDate = moment().add(-7, "days").startOf('week').format("YYYY-MM-DD"); //moment().subtract(1, 'months').format("YYYY-MM-DD");
        	var endDate =  moment().endOf('week').format("YYYY-MM-DD"); //moment(statDate).add(2, 'months').format("YYYY-MM-DD");
        	
        	frm.find("#dtpStartDate").val(statDate);
        	frm.find("#dtpEndDate").val(endDate);
        },
        initSearchFilterForm: function () {
            var frm = $(selector.frm_search_filter);
            frm.submit(function () {
            	fn.doSearchFilterFormSubmit.call(this);
                return false;
            });
        },
        initExportReportButtons: function() {
        	var btnExportReport = $(selector.btn_export_report);
        	btnExportReport.click(function() {
        		fn.doExportReport.call(this);
        		return false;
        	});
        },
        doSubmitForm: function() {
        	$(selector.frm_search_filter).submit();
        },
        doSearchFilterFormSubmit: function() {
        	var frm = $(this);
        	var startDate = frm.find("#dtpStartDate").val();
        	var endDate = frm.find("#dtpEndDate").val();
        	if((startDate == "")||(endDate == "")){
        		fn.mbox("Please select Date.")
        		return false;
        	}
        	if(endDate <= startDate){
        		fn.mbox("End Date Must be greater than Start Date.")
        		return false;
        	}
        	fn.fetchAndRenderChart(startDate, endDate);
        	
        	return false;
        },
        fetchAndRenderChart: function(startDate, endDate) {
        	startDate = startDate || "2017-01-01";
        	endDate = endDate || "2017-12-12";
        	
        	if(startDate != "") {
        		startDate = moment(startDate).format("YYYY-MM-DD"); 
        	}
        	if(endDate != "") {
        		endDate = moment(endDate).format("YYYY-MM-DD");
        	}
        	
        	var postData = $.param({
        		startDate: startDate,
        		endDate: endDate
        	});
        	
        	var url = variable.url_data_for_resource + "?" + postData;
        	ods.remoting.executeGet(url, "JSON", function(response) {
        		var chartDataRaw = response;
        		variable.startDate = startDate,
                variable.endDate = endDate
                variable.reportData = chartDataRaw;
        		var chartData = fn.transposeChartDataForFusionCharts(chartDataRaw, startDate, endDate);
                fn.renderChart(chartData);
        	}, function (jqXHR, status, err) {
            	if(jqXHR.responseJSON && jqXHR.responseJSON.message) {
            		fn.mbox(jqXHR.responseJSON.message, "Error");
            		return false;
            	}
            	fn.mbox("failure", "Error");
            });
        },
        renderChart: function (chartData) {
            FusionCharts.ready(function () {
            	var totalRows = 2;
		    	if(chartData.processes && chartData.processes && chartData.processes.process.length > 0) {
		    		totalRows = chartData.processes.process.length  + 1; //one extra header row
		    	} 
		    	var headerHeight = 50;
		        var rowHeight = 25;
		        var totalHeight = (totalRows*rowHeight) + headerHeight;
		        var chartHeight = Math.min(totalHeight, variable.chartDefaultHeight);
		        variable.chartHeight = chartHeight;
                var fusioncharts = new FusionCharts({
                    type: 'gantt',
                    renderAt: 'chart-container',
                    width: variable.chartWidth,
		            height: chartHeight,
                    dataFormat: 'json',
                    dataSource: chartData
                });
                fusioncharts.render();
            });
        },
        transposeChartDataForFusionCharts: function(data, startDate, endDate) {
        	var allResources = data.tasksByResource || {};
        	
            var chartData = fn.getEmptyChartData();
        	
        	var chartProcesses = [];
        	var chartActivity = [];
        	var chartTasks = [];
        	var milestoneCheck = [];
            
            	
            var count = 0;
            var countSecond = 0;
            var countM = 0;
            
            var maxEndDate = moment(startDate).toDate(); //used to trim the output final gantt chart if no data is present so we can trim it
            var minStartDate = moment(endDate).toDate(); //used to trim the output final gantt chart if no data is present so we can trim it

        	var previousProcessName = null;
            _.forEach(allResources, function (daysData, key, all) {
            	var rowIndex = 0;
                var resourceName = key;
                var allDays = daysData;
                
            	_.forEach(allDays, function(task, index, all) {
	                //First Column - Project
	                var keyChartProcessid = 'resource_' + resourceName + "_" + index;
	                var keyProgramDisplayText = (rowIndex == 0) ? resourceName : "";
	                var objProcess = {
	                    label: keyProgramDisplayText,
	                    id: keyChartProcessid
	                };
	                chartProcesses.push(objProcess);
	
	            	//tasks
	                var endDateMoment = moment(task.projectedEndDate).set(variable.eod);
	                var startDateMoment = moment(task.actualStartDate);
	                maxEndDate = (endDateMoment.toDate() > maxEndDate) ? endDateMoment.toDate() : maxEndDate;
	                minStartDate = (startDateMoment.toDate() < minStartDate) ? startDateMoment.toDate() : minStartDate;
                    var taskStartDate = startDateMoment.toDate();
                    var taskFinishDate = endDateMoment.toDate();
                    var percentAllocation = (task.percentAllocation||0) + "%";
                    var phaseTooltext = [
        				"Start Date: " + moment(taskStartDate).format("MM/DD/YYYY"),
        				"Projected End Date: " + moment(taskFinishDate).format("MM/DD/YYYY"),
        				"Key: " + task.key,
        				"Project Name: " + task.projectName,
        				"Task Name: " + task.name,
        				"Status: " + task.status,
        				"Description: " + task.description,
        				"PercentAllocation: " + percentAllocation
					].join("<br/>");
		
                    var taskColor = fn.getBarColor(task);
                    var chartTaskForPhase = {
	                    id: 'PRJ' + countSecond,
	                    processid: keyChartProcessid,
	                    start: taskStartDate,
	                    end: taskFinishDate,
	                    color: taskColor,
	                    label: task.name + " of " + task.projectName + " ("+percentAllocation+")",
	                    tooltext: phaseTooltext
                    };
                    chartTasks.push(chartTaskForPhase);
                    countSecond++;
                    
                    countM++;

	                rowIndex++;
            	});	
            	
            	
                previousProcessName = resourceName;
            });

            var filterdCategory = fn.generateDateRangeCategoriesForFusionChart(minStartDate, maxEndDate);
            
            
            chartData.processes.process = chartProcesses;
            chartData.datatable.datacolumn[0].text = chartActivity;
            chartData.tasks.task = chartTasks;
            chartData.milestones.milestone = milestoneCheck;
            chartData.categories[0].category = filterdCategory;
            chartData.categories = filterdCategory;
                
            console.log("chartProcesses: ", chartProcesses);
            console.log("chartActivity: ", chartActivity);
            console.log("chartTasks: ", chartTasks);
            console.log("chartMilestone: ", milestoneCheck)
        	
        	
        	if(chartData.datatable.datacolumn[0].text.length == 0) {
        		delete chartData.datatable.datacolumn;
        	}
        	console.log(chartData);
        	return chartData;
        },
        generateDateRangeCategoriesForFusionChart: function(startDate, endDate) {
        	var result = [];
        	var days = [];
        	
        	startDate = moment(startDate).toDate();
        	endDate = moment(endDate).toDate();
        	var start = moment(startDate).toDate();
        	for(var dt=start ; dt<=endDate ; dt=moment(dt).add(1, "days").toDate()) {
        		var mdt = moment(dt);
        		var dayItem = {
    				"start":  mdt.toDate(),
                    "end":  mdt.set(variable.eod).toDate(),
                    "label": mdt.format("M/D") +"<br/>" + mdt.format("ddd")
        		};
        		days.push(dayItem);
        	}
        	
            result.push({ category: days});
            	
        	return result;
        },
        getBarColor: function(task) {
        	var green = "#6caa03";
        	var chartColor = green;
        	switch(task.status) {
        		case "To Do":
        			chartColor = "#028fe4"; //blue
        			break;
        		default:
        			chartColor: green;
        	}
        	return chartColor;
        },
    	getEmptyChartData: function() {
        	
        	var chartData = {
                "chart": {
                    "dateformat": "mm/dd/yyyy",
                    "outputdateformat": "mm/dd",
                    "caption": "",
                    "captionFontSize": "14",
                    "subCaption": "",
                    "subCaptionFontSize": "12",
                    /*"ganttPaneDuration": "8",
                    "ganttPaneDurationUnit": "y",*/
                    
                    //"palette": "2",
                    "showLegend": "0",
                    "captionFontSize": "14",
                    "subCaptionFontSize": "12",
                    "labelDisplay": "wrap",
                    //"forceRowHeight": "1",
                    "scrollShowButtons": "1",
                    "showFullDataTable": "0",
                    "legendPosition": "top",
                    "legendAllowDrag": "1",
                    "plottooltext": "<div id='nameDiv'>Start Date - $start <br> End Date - $end</div>",
                    "milestoneFont": "Times New Roman",
                    "milestoneFontSize": "15",
                    "exportEnabled": "0",
                    "exportFormats": "PDF=Export As PDF|JPG=Export As JPG",
                    "dataEmptyMessage": "No Data Found",
                    "dataInvalidMessage": "No Data Found",
                    "taskBarFillMix": "light+0"
                },
                "categories": [{
                	"bgcolor": "#999999",
                    "category": []
                }],
                "processes": {
                    "fontsize": "12",
                    "isbold": "1",
                    "align": "left",
                    "headerbgcolor": "#ffffff",
                    "headertext": "",
                    "headerfontsize": "14",
                    "headervalign": "middle",
                    "headeralign": "left",
                    "width": "30%",
                    "process": []
                },
                "datatable": {
                    "showprocessname": "1",
                    "namealign": "left",
                    "fontcolor": "#000000",
                    "fontsize": "10",
                    "valign": "middle",
                    "align": "left",
                    "headervalign": "bottom",
                    "headeralign": "center",
                    "headerbgcolor": "#ffffff",
                    "headerfontcolor": "#000000",
                    "headerfontsize": "12",
                    "datacolumn": [{
                        "headertext": "Activity",
                        "text": []
                    }]
                },
                "tasks": {
                    "showlabels": "1",
                    "showstartdate": "1",
                    "showenddate": "1",
                    "task": []
                },
                "milestones": {
                    "milestone": []
                }
            };
        	chartData.processes.process = []; //empty, it as we will populate it dynamically
        	chartData.datatable.datacolumn[0].text = []; //empty it as we will populate it dynamically
        	return chartData;
        },
        doExportReport: function() {
        	fn.doExportReportForCSV.call(this); //hardcode to CSV for now
        },
        doExportReportForCSV: function() {
        	var data = fn.transposeChartDataForExport(variable.reportData);
        	
        	var defaultHeaders = (data.length > 0) ?fn.getKeysAsKVP(data[0]) : null;
        	
        	//header definitions
        	var headers = {
        		"resourceName": "Resource Name",
        		"plannedStartDate": {
        			name: "Planned Start Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        		"plannedEndDate": {
        			name: "Planned End Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        		"actualStartDate": {
        			name: "Actual Start Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        		"actualEndDate": {
        			name: "Actual End Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        		"createdDatetime": {
        			type: "date",
        			format: "MM/DD/YYYY HH:mm:ss"
        		},
        		"lastModifiedDatetime": {
        			type: "date",
        			format: "MM/DD/YYYY HH:mm:ss"
        		},
        		"projectedEndDate": {
        			name: "Projected End Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        		"dueDate": {
        			name: "Due Date",
        			type: "date",
        			format: "MM/DD/YYYY"
        		},
        	};
        	
        	var mergedHeaders = $.extend({}, defaultHeaders, headers);
        	
        	
        	var csvString = fn.convertArrayToCsv(data, mergedHeaders);
        	var fileName = ["TaskForResources", variable.startDate, "to", variable.endDate].join('_') + '.csv';
        	fn.downloadContent(csvString, fileName);
        },
        transposeChartDataForExport: function(data) {
        	var allResources = fn.clone(data.tasksByResource || {});
        	var chartData = [];
        	_.forEach(allResources, function (daysData, key, all) {
                var resourceName = key;
                var allDays = daysData;
                
            	 _.forEach(allDays, function(task, index, all) {
    				task.resourceName = resourceName;
    				chartData.push(task);
            	});
                
        	});
        	return chartData;
        },
        convertArrayToCsv: function(rows, headers) {
        	rows = rows || [];
        	var csvRows = [];
        	
        	//header row
        	if(rows.length > 0) {
        		var headerRow = fn.convertToCsvHeaderRow(rows[0], headers);
        		csvRows.push(headerRow);
        	}
        	
        	//data rows
        	for(var i=0 ; i<rows.length ; i++) {
        		var row = rows	[i];
        		var csvRow = fn.convertToCsvRow(row, headers);
        		csvRows.push('"' + csvRow.join('","') + '"');
        	}
        	var csvString = csvRows.join("\r\n");
        	return csvString;
        },
        
        convertToCsvHeaderRow: function(row, headers) {
        	headers = headers || fn.getKeysAsKVP(row, headers);
        	var cols=[];
        	
        	//generate headers
        	for (var property in headers) {
        	    if (headers.hasOwnProperty(property)) {
            		var header = headers[property];
            		var headerName = property;
            		if(typeof(header) == "object") {
            			headerName = header.name || property;
            		}
            		cols.push(headerName)
        	    }
        	}
        	return cols;
        },
        convertToCsvRow: function(row, headers) {
        	headers = headers || fn.getKeysAsKVP(row, headers);
        	var cols=[];
        	
        	//generate rows
        	for (var property in headers) {
        	    if (headers.hasOwnProperty(property)) {
        	    	
        	    	var header = headers[property];
            		var colName = property;
            		var value = row[colName];
            		
            		if(value && typeof(header) == "object") {
            			if(header.type == "date") {
            				value = moment(value).format(header.format || "MM/DD/YYYY HH:mm:ss")
            			}
            		}
            		
            		cols.push(value)
        	    }
        	}
        	return cols;
        	
        },
        getKeysAsKVP: function(data, defaultHeaders) {
        	defaultHeaders = defaultHeaders || {};
        	var keysArray = Object.keys(data);
        	//now convert them into array
        	var resultKVP = keysArray.reduce(function(result, item, index, array) {
    		  result[item] = defaultHeaders[item] || item; //if we have default header set then use that else use item as is.
    		  return result;
    		}, {});
        	
        	return resultKVP;
        },
        downloadContent: function(data, fileName) {
       	 var exportLink = document.createElement('a');
       	    exportLink.setAttribute('href', 'data:text/csv;base64,' + window.btoa(unescape(encodeURIComponent(data))));
            exportLink.setAttribute("download", fileName)
            exportLink.appendChild(document.createTextNode(fileName));
            $("#results").empty();
            document.getElementById('results').appendChild(exportLink).click();;
            $("#results").empty().hide();
        },
        clone: function(data, settings) {
        	settings = settings || {};
        	return $.extend(true, {}, data, settings);
        },
        mbox: function (message, title) {
            BootstrapDialog.show({
                title: title || 'Message',
                message: message
            });
        },
        
    };
    return {
        init: function () {
            fn.init();
        }
    };

}();

jQuery(document).ready(function ($) {
    $(function () {
    	TaskForResourcePageScript.init();
    });
});