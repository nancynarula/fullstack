package com.test.dto;

import java.io.Serializable;

public class TaskDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String taskName;
	private String taskDesc;
	private String taskStartDateStr;
	private String taskEndDateStr;
	private String taskStatus;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDesc() {
		return taskDesc;
	}
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	public String getTaskStartDateStr() {
		return taskStartDateStr;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public void setTaskStartDateStr(String taskStartDateStr) {
		this.taskStartDateStr = taskStartDateStr;
	}
	public String getTaskEndDateStr() {
		return taskEndDateStr;
	}
	public void setTaskEndDateStr(String taskEndDateStr) {
		this.taskEndDateStr = taskEndDateStr;
	}
	
	
	
	

}
