package com.test.dto;

import java.io.Serializable;
import com.google.gson.annotations.SerializedName;
public class JSONResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// success or failure
	private String status;
	// message in case of failure, or success
	private String message;

	// optional response code e.g. 200,301, 302, 404 etc. may be we can use it
	// in future.

	@SerializedName(value = "response_code")
	private String responseCode;

	// any java object which we can parse in JavaScript as JSON.

	@SerializedName(value = "response_data")
	private Object responseData;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	/**
	 * User friendly message e.g. what information you are sending from sever to
	 * client, is there any exception occurred while communicating data from
	 * server to client etc.
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * Optional response code, we can use for different tracking or operation on
	 * client side.
	 * 
	 * @param responseCode
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public Object getResponseData() {
		return responseData;
	}

	/**
	 * Response payload data, it could be anything plain text, list, map
	 * whatever application need to send from server to client.
	 * 
	 * @param responseData
	 */
	public void setResponseData(Object responseData) {
		this.responseData = responseData;
	}
}
