package com.test.dao;

import org.springframework.stereotype.Repository;

import com.test.Exception.SequenceException;

@Repository
public interface CounterDao {
	
	Long getNextSequenceId(String key) throws SequenceException;


}
