package com.test.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.test.dto.TaskDTO;

@Service
public interface TaskService {
	
	public List<TaskDTO> getTasks();
	
	public void saveTask(TaskDTO task);
	
	public void deleteTasks(Long id);
	
	public void changeStatus(Long id);

	
		

}
