package com.test.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.dao.CounterDao;
import com.test.dto.TaskDTO;
import com.test.model.Task;
import com.test.repository.TaskRepository;
import com.test.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService{

	@Autowired
	TaskRepository taskRepository;
	
	private static final String TASK_SEQ_KEY = "taskId";

	@Autowired
	private CounterDao counterDao;

	
	@Override
	public List<TaskDTO> getTasks() {
		SimpleDateFormat sdf= new  SimpleDateFormat("dd-MMM-yyyy");
		List<Task> taskList=taskRepository.findAll();
		
		List<TaskDTO> taskDTOList= new ArrayList<>();
		for(Task task:taskList){
			TaskDTO taskDto= new TaskDTO();
			BeanUtils.copyProperties(task, taskDto);
			
			taskDto.setId(task.getTaskId());
			if(task.getTaskStartDate()!=null)
				taskDto.setTaskStartDateStr(sdf.format(task.getTaskStartDate()));
			
			if(task.getTaskEndDate()!=null)
				taskDto.setTaskEndDateStr(sdf.format(task.getTaskEndDate()));
			
			taskDTOList.add(taskDto);
			
		}
		
		
		return taskDTOList;
	}
	
	public void saveTask(TaskDTO taskDto){
		SimpleDateFormat sdf= new  SimpleDateFormat("dd-MMM-yyyy");
		
		Task task;
		if(taskDto.getId()!=null)
		task = taskRepository.findOne(taskDto.getId());
		else{
		task= new Task();	
		task.setTaskId(counterDao.getNextSequenceId(TASK_SEQ_KEY));
		}
		
		BeanUtils.copyProperties(taskDto, task);
		
		if(taskDto.getTaskStartDateStr()!=null)
			try {
				task.setTaskStartDate(sdf.parse(taskDto.getTaskStartDateStr()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		if(taskDto.getTaskEndDateStr()!=null)
			try {
				task.setTaskEndDate(sdf.parse(taskDto.getTaskEndDateStr()));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		taskRepository.save(task);
	}	

	
	public void deleteTasks(Long id){
		
		List<Task> t=taskRepository.findByTaskId(id);
		if(t!=null)
			taskRepository.delete(id);		
		
	}
	
	public void changeStatus(Long id){
		
		Task task=taskRepository.findOne(id);
	
		if(task.getTaskStatus().equalsIgnoreCase("Pending"))
				task.setTaskStatus("Completed");
		
		taskRepository.save(task);
	}
}
