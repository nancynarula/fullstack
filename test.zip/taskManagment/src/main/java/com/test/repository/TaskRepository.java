package com.test.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.test.model.Task;


public interface TaskRepository extends MongoRepository<Task, Long> {
	
	public List<Task> findByTaskStatus(String taskStatus);
	
	public List<Task> findByTaskId(Long id);

	
	
}
