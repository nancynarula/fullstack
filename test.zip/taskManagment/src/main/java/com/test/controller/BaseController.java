package com.test.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.test.dto.JSONResponse;



public abstract class BaseController {
	

		protected ResponseEntity<JSONResponse> getSuccessReponse(Object data, String message) {
			JSONResponse response = new JSONResponse();
			response.setStatus("SUCCESS");
			response.setResponseCode("200");
			response.setResponseData(data);
			response.setMessage(message);
			return new ResponseEntity<JSONResponse>(response, HttpStatus.OK);
		}

		protected ResponseEntity<JSONResponse> getFailureReponse(Object data, String message) {
			JSONResponse response = new JSONResponse();
			response.setResponseCode("500");
			response.setStatus("FAILURE");
			response.setResponseData(data);
			response.setMessage(message);
			return new ResponseEntity<JSONResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}




}
