package com.test.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.test.dto.JSONResponse;
import com.test.dto.TaskDTO;
import com.test.service.TaskService;

@RequestMapping("/task")
@RestController
public class TaskController extends BaseController{
	

	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	TaskService taskService;
	/**
	 * This method provides presentation view for task (using HTML).
	 * 
	 * @return
	 */
	@GetMapping(value = { "/view" })
	public ModelAndView getProjectView() {
		ModelAndView mv = new ModelAndView("tasks/task");
		return mv;
	}

	
	@GetMapping("/all")
	public ResponseEntity<JSONResponse> getAllRecords() {
		try {
			List<TaskDTO> records = taskService.getTasks();
			return super.getSuccessReponse(records, "");
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return super.getFailureReponse(null, e.getMessage());
		}
	}
	
	@PostMapping(value = "/create")
	public ResponseEntity<JSONResponse> create(@RequestBody TaskDTO request) {
		try {
			 taskService.saveTask(request);
			return super.getSuccessReponse("", "Saved successfully!!");
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return super.getFailureReponse(null, e.getMessage());
		}
	}
	
	
	
	 @GetMapping("/delete/{id}")
	public ResponseEntity<JSONResponse> delete(@PathVariable("id") final Long id) {
		try {
		 taskService.deleteTasks(id);
			return super.getSuccessReponse("", "Record Deleted");
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return super.getFailureReponse(null, e.getMessage());
		}
	}
	
}
